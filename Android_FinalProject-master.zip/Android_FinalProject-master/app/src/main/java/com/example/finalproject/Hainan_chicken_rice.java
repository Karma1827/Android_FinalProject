package com.example.finalproject;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.LinkedList;

public class Hainan_chicken_rice extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private WordListAdapter mAdapter;
    private ImageView image;
    LinkedList<String> hainan_chicken_rice = new LinkedList<String>( Arrays.asList(
            "Description: ",
            "Juicy and Tender steamed chicken dipping with fresh homemade chili sauce , rounded up all together with oily rice.",
            " ",
            "------------ Ingredients ------------",
            "CHICKEN INGREDIENT",
            "0.5 kg Chicken Breast Fillet",
            "0.5 teaspoon Salt",
            "0.25 inch Ginger",
            "0.5 cloves Garlic",
            "RICE INGREDIENT",
            "0.5-3 cup Rice",
            "0.25 bowl Chicken Stock",
            "0.5 tablespoon Cooking Oil",
            "0.25 pinch Salt",
            "1 clove Garlic",
            "0.25 leaf Pandan Leaf",
            "CHILI SAUCE INGREDIENT",
            "25g Red Chili",
            "15g Ginger",
            "35g Garlic",
            "35g Calamansi Juice",
            "25g Vinegar",
            "20g Sugar",
            "0.25 teaspoon Salt",
            "GINGER SAUCE INGREDIENT",
            "80g Ginger Sauce Ingredient Ginger",
            "0.25/2 teaspoon Salt",
            "1 tablespoon Cooking Oil",
            "SWEET SOY SAUCE INGREDIENT",
            "50g Sweet Soy Sauce Ingredient Sweet Soy Sauce",
            "37.5ml Water",
            "20g Rock Sugar",
            " ",
            "------------ Procedure ------------",
            "PREPARING CHILI SAUCE (1mins)",
            "Mix Chili Pepper, Red Chili, Ginger, Garlic, Calamansi Juice, Vinegar, Sugar, Salt into blender then turn it into sauce.",

            "PREPARING GINGER SAUCE (4mins)",
            "Wash ginger, use grater to turn it into paste.Mix ginger paste with salt and garlic oil.",

            "PREPARING SWEET SOY SAUCE (5mins)",
            "Fill water into pot then add crystal sugar keep stirring until dissolved. ",
            "Add in dark soy sauce and continue stirring until starts to boil, ready to serve.",

            "COOKING CHICKEN (30mins)",
            "Wash the salt covering the chicken and stuff in remaining salt , ginger and garlic into the chicken. ",
            "Put chicken into boiling pot, use medium heat and cook for 10 mins and take out the chicken. ",
            "Put chicken back into boiling pot and cook for 10 mins. Switch off the fire ,put on the pot cover and let it cook for another 10 mins. " ,
            "Take the chicken out from the pot, cut the chicken into pieces and ready to serve.",

            "COOKING CHICKEN RICE(15mins)",
            "While cooking/chilling chicken, wash 3 cups of rice and let it soak inside water for 10 mins. ",
            "Heat up a pan with vegetable oil, add in garlic ,pandan leaf and dried rice. ",
            "Stir fry for around 5 mins , add in salt and chicken stock then transfer into rice cooker and set to cook."
            ));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.recyclerview );
        mRecyclerView = findViewById(R.id.recyclerview);
        mAdapter = new WordListAdapter(this, hainan_chicken_rice);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        image = findViewById( R.id.imageView);
        image.setImageResource( R.drawable.hainan_rice );
    }
}
