package com.example.finalproject;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.LinkedList;

public class Pineapple_fried_rice extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private WordListAdapter mAdapter;
    private ImageView image;
    LinkedList<String> pineapple_fried_rice = new LinkedList<String>( Arrays.asList(
            "Description: ",
            "There’s various versions of Pineapple Fried Rice around, and this is Vietnamese version. The sweet, juicy pieces of pineapple goes so well with the savoury flavoured jasmine rice! Terrific side dish for tropical dishes, summer BBQ’s and of course, with all things Vietnam.",
            " ",
            "------------ Ingredients ------------",
            "Ingredients",
            "2 tbsp vegetable oil",
            "2 garlic cloves , finely minced",
            "1/2 onion , finely chopped",
            "1/2 red capsicum / bell peppers , diced (~ 3/4 cup)",
            "1/2 cup peas , frozen",
            "3 cups day old jasmine rice , cooked (Note 1)",
            "220g pineapple pieces",
            "1/2 cup green onion , sliced",
            "SAUCE",
            "1 tbsp oyster sauce",
            "1 1/2 tbsp fish sauce",
            "1/2 tsp sugar",
            " ",
            "------------ Procedure ------------",
            "Heat oil in a wok or large non stick skillet over high heat.",
            "Add garlic and onion, cook for 1 minute.",
            "Add capsicum, cook for 1 minute.",
            "Add peas, stir for 30 seconds.",
            "Add rice and Sauce ingredients of choice. Cook, stirring constantly, for 2 minutes or until rice grains goes from being wet with sauce to sort of caramelised.",
            "Add pineapple, stir for just 30 seconds to warm through.",
            "Stir through green onions then serve!"
    ));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.recyclerview );
        mRecyclerView = findViewById(R.id.recyclerview);
        mAdapter = new WordListAdapter(this, pineapple_fried_rice);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        image = findViewById( R.id.imageView);
        image.setImageResource( R.drawable.pineapple_rice );
    }
}

