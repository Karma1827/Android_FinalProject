package com.example.finalproject;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.LinkedList;

public class Coffee extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private WordListAdapter mAdapter;
    private ImageView image;
    LinkedList<String> coffee = new LinkedList<String>( Arrays.asList(
            "Description: ",
            "Vietnamese sweet and sour soup or canh chua is a famous soup. It is usually served with a long braised catfish as part of a dinner menu. The dish consists of fish, tomatoes, pineapple, okra, bean sprouts and tamarind. The sour taste of the soup comes from fresh tamarind, usually diluted with water, then added to the soup.",
            " ",
            "------------ Ingredients ------------",
            "1 tablespoon ground chicory coffee",
            "2 tablespoons sweetened condensed milk",
            "1 cup hot water (240 mL)",

            " ",
            "------------ Procedure ------------",
            "Pour the ground coffee into a Vietnamese phin filter base. Place the phin filter strainer on top of the coffee.",
            "Pour the sweetened condensed milk into a glass." ,
            "Place the phin assembly on top of the glass. Pour hot water into the phin filter. Place the phin filter lid on top and let the coffee drip through the filter into the glass.",
            "Stir well before serving.",
            "Enjoy!"
    ) );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.recyclerview );
        mRecyclerView = findViewById( R.id.recyclerview );
        mAdapter = new WordListAdapter( this, coffee );
        mRecyclerView.setAdapter( mAdapter );
        mRecyclerView.setLayoutManager( new LinearLayoutManager( this ) );
        image = findViewById( R.id.imageView );
        image.setImageResource( R.drawable.coffee );
    }
}

