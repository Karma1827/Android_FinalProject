package com.example.finalproject;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.LinkedList;

public class Canh_chua extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private WordListAdapter mAdapter;
    private ImageView image;
    LinkedList<String> canh_chua = new LinkedList<String>( Arrays.asList(
            "Description: ",
            "Vietnamese sweet and sour soup or canh chua is a famous soup. It is usually served with a long braised catfish as part of a dinner menu. The dish consists of fish, tomatoes, pineapple, okra, bean sprouts and tamarind. The sour taste of the soup comes from fresh tamarind, usually diluted with water, then added to the soup.",
            " ",
            "------------ Ingredients ------------",
            "1 ½lb pork",
            "1 yellow onion",
            "1 ½oz fresh tamarind",
            "1tsp salt",
            "1 can pineapple 20 oz",
            "1 piece ginger 1inch long",
            "1 ½lb catfish cut into 1 inch pieces",
            "10oz elephant ear stem cut into chunks",
            "3 tomatoes quartered",
            "12oz bean sprouts",
            "1tsp granulated sugar",
            "1oz rice paddy herb",

            " ",
            "------------ Procedure ------------",
            "Add pork to a large soup pot. Cover with water until it just covers the pork. Bring to a boil and simmer for 10 minutes. Take out the pork and then throw away the water. This process cleans the pork. Rinse the pot and add the pork back. Cover the pork with fresh water until it just covers the meat. Bring to a boil.",
            "Add the onion and simmer for 1.5 hours. Make sure to check every 30 minutes for impurities. Scoop away any you see.",
            "While the soup is simmering, combine 1 cup of water and tamarind in a small saucepan. Bring to a boil and let it simmer until the tamarind dissolves.You can help speed up the process by using the back of a spoon to crush the tamarind. Pour the tamarind through a fine mesh sieve into a small bowl. Set aside.",
            "After simmering the soup for 1.5 hours, add the pineapple to the soup. Simmer for another 20 minutes.",
            "Put the catfish in and simmer for another 10 minutes until it is cooked through.",
            "Lastly, add the vegetables and tamarind from step 3. Bring the soup to a boil and serve with a side of white rice. Make sure to taste the soup for seasoning and add more salt if it tastes bland."
    ) );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.recyclerview );
        mRecyclerView = findViewById( R.id.recyclerview );
        mAdapter = new WordListAdapter( this, canh_chua );
        mRecyclerView.setAdapter( mAdapter );
        mRecyclerView.setLayoutManager( new LinearLayoutManager( this ) );
        image = findViewById( R.id.imageView );
        image.setImageResource( R.drawable.canh_chua );
    }
}
