package com.example.finalproject;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.LinkedList;

public class Fried_noodle extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private WordListAdapter mAdapter;
    private ImageView image;
    LinkedList<String> fried_noodle = new LinkedList<String>( Arrays.asList(
            "Description: ",
            "One of the most epic noodle dishes in the world from the streets of Malaysia: Char Kway Teow! Big flavours, contrasting textures and the signature hint of charred smokiness, this is bold South East Asian food at its best!",
            " ",
            "------------ Ingredients ------------",
            "500g / 1 lb fresh wide rice noodle",
            "2tbsp lard , or vegetable oil",
            "2tbsp vegetable oil , separated",
            "10 small prawns/shrimp , shelled and deveined",
            "2 garlic cloves , finely chopped",
            "1 Chinese sausage / Lup Chong Sausage , sliced thinly on the diagonal",
            "5cm / 2 piece of fried fish cake , sliced thinly",
            "20 stems garlic chives , cut into 4 pieces",
            "2 1/2 cups bean sprouts",
            "2 eggs , whisked",

            "SAUCE:",
            "5tsp dark soy sauce",
            "4tsp light soy",
            "2tsp oyster sauce ",
            "4tsp kecap manis / sweet soy sauce",
            " ",
            "------------ Procedure ------------",
            "Mix Sauce together.",

            "NOODLES:",
            "Do not attempt to pull noodles apart while cold and hard - they break. ",
            "Place whole packet in microwave, heat on high for 1 1/2 minutes - 2 minutes until warm and pliable, not hot, turning packet over as needed.",
            "Handle carefully and measure out 500g/1 lb noodles into a heatproof bowl. Separate noodles stuck together.",
            "If noodles become cold and brittle before cooking, cover with cling wrap and microwave for 30 seconds to make warm (not hot, just warm) to reduce breakage.",

            "COOKING: ",
            "Heat lard and 1 tbsp oil in a wok or very large heavy based skillet over high heat. Swirl around the wok.",
            "When it starts smoking, add prawns. Cook for 30 seconds.",
            "Add garlic, stir for 10 seconds.",
            "Add noodles, then using both hands on the handle, toss 4 times until coated with oil (or gently fold using a spatula + wooden spoon, see video).",
            "Add Chinese sausage and fish cake, toss or gently fold 4 times.",
            "Add bean sprouts and garlic chives, toss or gently fold 6 times.",
            "Push everything to one side, add remaining 1 tbsp oil. Add egg and cook, moving it around until mostly set - about 1 minute. Use wooden spoon to chop it up roughly.",
            "Pour Sauce over noodles, then toss to disperse Sauce through the noodles. Pause between tosses to give the noodles a chance to caramelise on the edges."
    ));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.recyclerview );
        mRecyclerView = findViewById(R.id.recyclerview);
        mAdapter = new WordListAdapter(this, fried_noodle);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        image = findViewById( R.id.imageView);
        image.setImageResource( R.drawable.fried_noodle);
    }
}