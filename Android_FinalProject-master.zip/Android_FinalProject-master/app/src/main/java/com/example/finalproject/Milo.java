package com.example.finalproject;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.LinkedList;

public class Milo extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private WordListAdapter mAdapter;
    private ImageView image;
    LinkedList<String> milo = new LinkedList<String>( Arrays.asList(
            "Description: ",
            "Milo is a chocolate flavoured malted powder product produced by Nestlé, typically mixed with milk, hot water, or both, to produce a beverage.",
            " ",
            "------------ Ingredients ------------",
            "6 Tbsp Nestle Milo Powder",
            "100ml Hot Water",
            "3/4 - 1 Tbsp Sweetened Creamer/Condensed Milk",
            "A few Ice Cubes",
            "2-3 Tbsp Nestle Milo Powder for sprinkling",
            " ",
            "------------ Procedure ------------",
            "Mix Nestle Milo powder and Sweetened Creamer along with Hot Water in a tall glass, stir until all the above ingredients are well incorporated.",
            "Top it up with Ice Cubes and give a quick stir.",
            "Sprinkle ample amount of Nestle Milo Powder over the drink."
    ));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.recyclerview );
        mRecyclerView = findViewById(R.id.recyclerview);
        mAdapter = new WordListAdapter(this, milo);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        image = findViewById( R.id.imageView);
        image.setImageResource( R.drawable.milo );
    }
}

