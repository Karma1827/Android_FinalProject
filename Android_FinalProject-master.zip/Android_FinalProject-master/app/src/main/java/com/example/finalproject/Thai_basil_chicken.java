package com.example.finalproject;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.LinkedList;

public class Thai_basil_chicken extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private WordListAdapter mAdapter;
    private ImageView image;
    LinkedList<String> thai_basil_chicken = new LinkedList<String>( Arrays.asList(
            "Description: ",
            "A tangy, spicy, salty and subtly sweet stir fry with holy basil and chilies and minced thigh fillets were used in this Thai basil chicken (pad krapow gai or phat kaphrao gai) recipe.",
            " ",
            "------------ Ingredients ------------",
            "6 to 8 chicken thigh fillets",
            "4 cloves garlic",
            "2 bird’s eye chilies",
            "1 one-inch knob ginger",
            "2 shallots, or 1 small red onion, thinly sliced",
            "2 tablespoons cooking oil",
            "3 tablespoons soy sauce",
            "juice of 1 lime",
            "2 tablespoons sugar",
            "fish sauce, to taste",
            "large handful holy basil leaves",
            "3 eggs, fried sunny side up, to serve",
            " ",
            "------------ Procedure ------------",
            "Pat the chicken fillets dry with paper towels. Mince the chicken to the size that you prefer.",
            "Mince the garlic.",
            "Finely slice the chilies.",
            "Peel and mince the ginger.",
            "Thinly slice (or roughly chop) the shallots or onion.",
            "Heat the cooking oil in a wok or frying pan. Saute the garlic, chilies, ginger and shallots or onion.",
            "Add the minced chicken. Stir fry until the meat changes color. Pour in the soy sauce and half of the lime juice. Add the sugar. Stir and pour in enough fish sauce to create the sweet-tangy-salty-spicy balance that you like. If you’re aiming for authenticity, the flavor should be more tangy and spicy than sweet and salty.",
            "Stir fry the chicken for three to four minutes. Add the holy basil leaves. Stir fry for another two to three minutes.",
            "Taste the chicken pad krapow. Adjust the seasonings, as needed, before serving with fried egg and rice."
            ));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.recyclerview );
        mRecyclerView = findViewById(R.id.recyclerview);
        mAdapter = new WordListAdapter(this, thai_basil_chicken);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        image = findViewById( R.id.imageView);
        image.setImageResource( R.drawable.thai_basil_chicken );
    }
}