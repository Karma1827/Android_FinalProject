package com.example.finalproject;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.LinkedList;

public class Canh_artiso extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private WordListAdapter mAdapter;
    private ImageView image;
    LinkedList<String> canh_artiso = new LinkedList<String>( Arrays.asList(
            "Description: ",
            "Artichoke flower can be cooked many artichoke dishes, especially artichoke flower use for  cooking artichoke soup, it is very tasty and good for your health, this soup will bring you a good liver and lungs, it is appropriate with the elderly or young children.",
            " ",
            "------------ Ingredients ------------",
            "400 g pork ribs, chopped into 2 cm pieces",
            "2 artichokes(600g) with stalks intact",
            "2.5 litres water",
            "1 teaspoon salt",
            "1 teaspoon sugar",
            "2 tablespoons fish sauce",
            " ",
            "------------ Procedure ------------",
            "Fill a large mixing bowl with cold water",
            "Slice the artichoke stalks into 4 cm pieces then cut the artichokes in quarters, removing any fuzzy parts. Immediately submerge the artichokes into the cold water to prevent it from going black.",
            "In a large pot, add pork ribs, artichokes, fish sauce, sugar, salt, pepper and 2.5 litres water. Bring to a boil then skim off any impurities for 10 minutes.",
            "Reduce the heat to a low simmer then close with lid. Simmer for 45 minutes.",
            "Always use a stainless-steel knife and submerge sliced artichokes in water to prevent the artichoke turning black."
    ) );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.recyclerview );
        mRecyclerView = findViewById( R.id.recyclerview );
        mAdapter = new WordListAdapter( this, canh_artiso );
        mRecyclerView.setAdapter( mAdapter );
        mRecyclerView.setLayoutManager( new LinearLayoutManager( this ) );
        image = findViewById( R.id.imageView );
        image.setImageResource( R.drawable.canh_chua );
    }
}