package com.example.finalproject;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.LinkedList;

public class Indo_fried_rice extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private WordListAdapter mAdapter;
    private ImageView image;
    LinkedList<String> indo_fried_rice = new LinkedList<String>( Arrays.asList(
            "Description: ",
            "Nasi Goreng is the popular Indonesian fried rice which is traditionally served with a fried egg. As with almost every traditional dish, there are many versions of Nasi Goreng.",
            " ",
            "------------ Ingredients ------------",
            "CHICKEN",
            "1 tbsp oil",
            "5 oz / 150g chicken breast , thinly sliced (or other protein)",
            "1 tbsp kecap manis (sweet soy sauce, Note 1)",
            "RICE",
            "1.5 tbsp oil",
            "2 garlic cloves , finely chopped",
            "1 tsp red chilli , finely chopped (Note 2)",
            "1 onion , small, diced",
            "3 cups cooked white rice , day old, cold (Note 3)",
            "2 tbsp kecap manis (sweet soy sauce, Note 1)",
            "2 tsp shrimp paste , optional (Note 4)",
            "GARNISHES / SIDE SERVINGS (OPTIONAL)",
            "4 eggs , fried to taste",
            "1 green onion , sliced",
            "Tomatos and cucumbers, cut into wedges/chunks",
            "Fried shallots , store bought (optional) (Note 3)",
            "Lime wedges",
            " ",
            "------------ Procedure ------------",
            "Heat oil in a large skillet or wok over high heat.",
            "Add chilli and garlic, stir for 10 seconds.",
            "Add onion, cook for 1 minute.",
            "Add chicken, cook until it mostly turns white, then add 1 tbsp kecap manis and cook for a further 1 minute or until chicken is mostly cooked through and a bit caramelised.",
            "Add rice, 2 tbsp kecap manis and shrimp paste, if using. Cook, stirring constantly, for 2 minutes until sauce reduces down and rice grains start to caramelise (key for flavour!).",
            "Serve, garnished with garnishes of choice (green onions, red chilli, fried shallots)."
    ));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.recyclerview );
        mRecyclerView = findViewById(R.id.recyclerview);
        mAdapter = new WordListAdapter(this, indo_fried_rice);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        image = findViewById( R.id.imageView);
        image.setImageResource( R.drawable.indon_rice);
    }
}
