package com.example.finalproject;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.LinkedList;

public class Bun_bo_hue extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private WordListAdapter mAdapter;
    private ImageView image;
    LinkedList<String> bun_bo_hue = new LinkedList<String>( Arrays.asList(
            "Description: ",
            "Bún bò Huế is a hidden Vietnamese gem that has yet to “make it” in mainstream American cuisine. It’s a rich and spicy soup with deep layers of flavor. This Central Vietnamese soup is paired with tender slices of beef and pork, then topped with lots of fresh herbs.",
            " ",
            "------------ Ingredients ------------",
            "113.4g beef shank",
            "113.4g oxtail",
            "013.4g pork hocks",
            "56.7g Huế style pork sausage chả Huế, which has garlic and whole peppercorns",
            "56.7g block of pork blood",

            "BROTH BASE & SEASONING",
            "water I used an 8 quart pot, and added water to cover the meat",
            "3 oz chicken broth",
            "1.5 stalks lemongrass leafy tops removed, roots smashed",
            "0.25 yellow onions, large halved",
            "0.38 tbsp salt",
            "0.25 tbsp sugar",
            "0.25 tbsp shrimp paste Lee Kum Kee brand",
            "0.38-0.5 tbsp fish sauce",
            "0.25 tsp MSG (monosodium glutamate) if not using oxtail, add 4 teaspoons",

            "AROMATICS & COLOR",
            "0.38 tbsp anatto seeds",
            "0.38 tbsp neutral cooking oil",
            "0.25 tbsp shallot sliced",
            "0.25 tbsp garlic minced",
            "HERBS & VEG",
            "mint",
            "basil",
            "bean sprouts",
            "birds eye chile or jalapeno",
            "lime sliced",

            "BANANA FLOWER",
            "0.13 banana flower",
            "0.25 cups water",
            "0.13 lemon juiced",

            "NOODLES",
            "49.61g package dried rice noodle medium or large thickness",
            "SATÉ (SPICY CHILE CONDIMENT)",
            "2.5g dried Thai chile crushed",
            "0.06c neutral cooking oil",
            "10g shallot or white onion minced",
            "5g garlic minced",
            "3.75g lemongrass minced",
            "0.25 tbsp Korean chile powder (gochugaru)",
            "0.13 tbsp fish sauce",
            "0.13 tbsp sugar",
            "0.08 tsp salt",
            "0.06 tsp MSG (monosodium glutamate)",
            " ",
            "------------ Procedure ------------",
            "BROTH",
            "Clean the meat: Add all meat to a stock pot and enough water to submerge it, bring to a boil. Drain and rinse thoroughly under running water.",
            "Add the meat, broth, lemongrass and onions to the pot and fill with water almost to the brim. Bring to a boil then drop the heat to medium-high to maintain a low boil. Add the seasoning.",
            "Let it simmer and periodically check the meats for doneness and remove them as they finish cooking. The pork should be done after about an hour, the beef can vary between 2-3 hours.",
            "After all the meat has removed, let it cool, then slice it. Adjust seasoning and add water to the broth pot if necessary.",
            "Make the aromatics & coloring then add it to the pot.",
            "Boil noodles according to package instructions.",
            "Assemble your bowl, and serve with herbs and veg on a side platter.",
            "RED COLORING & AROMATICS",

            "Sauté seeds in oil on medium heat until the seeds give up the bright red color, then remove the seeds.",
            "Add shallots and garlic, sauté until brown.",
            "Add all of this to the pot of broth for color.",
            "PORK BLOOD",

            "The easiest thing to do is just buy it already cooked and boil just to heat it up. If you use the raw type like we did for this recipe, cut into cubes and boil for 30-45 minutes",

            "BANANA FLOWER",
            "Prepare a bowl of about 2 cups of water, mixed with the juice of 1 lemon.",
            "Thinly slice the banana flower and add to the water mixture to sit for about 30 minutes.",
            "Avoid adding little fronds (that look like mini bananas), removing them as you encounter them. They taste bitter!",

            "SATÉ (SPICY CHILE CONDIMENT)",
            "Weigh out the dried Thai chiles, then soak in just enough warm water to cover the chiles for 20 minutes. Drain the water.",
            "Add all sate ingredients to a pan on medium heat and stir continuously to brown, cook, and slightly reduce the chile paste, about 30-40 minutes. If at any point it becomes too dry, you can add more oil, up to 50% of the amount we started with. Taste and reseason with sugar or salt as desired. See photo for how the final product should look.",
            "Let cool and transfer to a sealed jar stored in the fridge . You can add ~2 tbsp of the final product to the soup pot for a boost in flavor and color, or simply and let each person add to their bowl to make it as spicy as they'd like!"
            ));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.recyclerview );
        mRecyclerView = findViewById(R.id.recyclerview);
        mAdapter = new WordListAdapter(this, bun_bo_hue);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        image = findViewById( R.id.imageView);
        image.setImageResource( R.drawable.bun_bo_hue);
    }
}
