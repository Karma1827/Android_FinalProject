package com.example.finalproject;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.LinkedList;

public class Bun_thit_nuong extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private WordListAdapter mAdapter;
    private ImageView image;
    LinkedList<String> bun_thit_nuong = new LinkedList<String>( Arrays.asList(
            "Description: ",
            "A combination of steamy fragrant broken rice with tender pork cutlet, fresh vegetables, egg meatloaf or fried egg, and carrot pickles.",
            " ",
            "------------ Ingredients ------------",
            "Spring Roll:",
            "1 clove Garlic",
            "100g Garlic Chives",
            "2 tbsp Fish Sauce",
            "1 tsp Sugar",
            "1/2 bunch Coriander",
            "200g Shrimp",
            "350g Minced Pork",
            "2 tsp Salt",
            "1 tsp Ground Black Pepper",
            "8 sheet Rice Paper",
            "1 Egg",
            "Cooking Oil",

            "Fish Sauce:",
            "1 Garlic",
            "0.5 tsp Sugar",
            "100ml Water",
            "1 tsp Fish Sauce",
            "1 tbsp Lime Juice",
            "1 Bird's Eye Chili",

            "Grilled Pork:",
            "0.5 tbsp Sugar",
            "1 tbsp Fish Sauce",
            "0.25 stalk Lemongrass",
            "0.5 clove Garlic",
            "0.5 Shallot",
            "0.5 Red Chili",
            "0.5 tsp Ground Black Pepper",
            "0.25 kg Pork Meat",

            "INGREDIENT A",
            "200g Vietnam Vermicelli",
            "500ml Water",
            "100ml Sweet Sauce",
            "INGREDIENT B",
            "1/2 stick Carrot",
            "1 sprigs Spring Onion",
            "100g Toasted Ground Peanut",
            " ",
            "------------ Procedure ------------",
            "Spring Roll (15 mins)",
            "Coarsely chop the prawns and mix with the minced pork , seasoned with salt and pepper. Add ingredient A into prawn and pork mixture.",
            "Place 2 tablespoon of the prawn and minced pork mixture in the center of each sheet. Fold the lower edge of the sheet over the filling. Fold the left and the right edges inward , over the filling. Brush the remaining edge of the sheet with egg white and roll up tightly.",
            "Deep fry the spring roll in hot oil for 5 minutes until the rice paper turn golden brown. Allow to drain briefly on kitchen paper , then serve with sweet chili sauce.",

            "Fish Sauce (5mins)",
            "Add Ingredient A into a bowl, keep mashing until sugar fully dissolved. Toss in Ingredient B then mix and stir well. Ready to serve.",

            "Grilled Pork (20mins)",
            "Add Ingredient A into a bowl, stir until sugar fully dissolved. Place pork on a plate then pour in Ingredient A, make sure the marinate sauce are covering each surface of the pork evenly. Cover the plate and leave to marinate for 2 hours.",
            "Heat up a grill, put the marinated pork on top and let it grill for 10 minutes, flip side after 5 minutes. Remove pork from grill and cut into slices then arrange on a plate. Ready to serve.(Can use oven to replace grill, just make sure to observe and flip side when one side is cooked)",

            "VERMICELLI PREPARATION (10mins)",
            "Heat up a pot of water, soak vermicelli in until boil. Remove vermicelli from the pot and rinse until dry.",


            "DISH PREPARATION (5mins)",
            "Place vermicelli in a bowl, arrange Ingredient B then Grilled Pork and Spring Roll accordingly on top. Fill sweet sauce on a saucer plate and serve all together.",
            "(The correct way of eating this dish is to pour in the sweet sauce then mix evenly before eating)"
            ));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.recyclerview );
        mRecyclerView = findViewById(R.id.recyclerview);
        mAdapter = new WordListAdapter(this, bun_thit_nuong);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        image = findViewById( R.id.imageView);
        image.setImageResource( R.drawable.bun_thit_nuong);
    }
}
