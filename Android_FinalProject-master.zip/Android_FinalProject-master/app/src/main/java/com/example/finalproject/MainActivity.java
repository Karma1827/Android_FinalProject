package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "com.example.finalproject.extra.MESSAGE";
    private String mOrderMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TabLayout tabLayout = findViewById(R.id.tab_layout);
        // Set the text for each tab.
        tabLayout.addTab(tabLayout.newTab().setText(R.string.tab_label1));
        tabLayout.addTab(tabLayout.newTab().setText(R.string.tab_label2));
        tabLayout.addTab(tabLayout.newTab().setText(R.string.tab_label3));
        tabLayout.addTab(tabLayout.newTab().setText(R.string.tab_label4));
        tabLayout.addTab(tabLayout.newTab().setText(R.string.tab_label5));

        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        final ViewPager viewPager = findViewById(R.id.pager);
        final PagerAdapter adapter = new PagerAdapter(getSupportFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.addOnTabSelectedListener( new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            /*case R.id.action_order:
                Intent intent = new Intent(MainActivity.this, OrderActivity.class);
                intent.putExtra(EXTRA_MESSAGE, mOrderMessage);
                startActivity(intent);
                return true;*/
            case R.id.action_search:
                displayToast(getString(R.string.action_search_message));
                return true;
            case R.id.action_status:
                displayToast(getString(R.string.action_info_message));
                return true;
            case R.id.action_favorites:
                displayToast(getString(R.string.action_favorites_message));
                return true;
            default:
        }
        return super.onOptionsItemSelected(item);
    }

    private void displayToast(String string) {
        Toast.makeText(getApplicationContext(), string, Toast.LENGTH_LONG).show();
    }

    public void com_tam(View view){
        Intent intent = new Intent(this, Com_tam.class);
        startActivity( intent );
    }

    public void nasi_lemak(View view){
        Intent intent = new Intent(this, Nasi_lemak.class);
        startActivity( intent );
    }

    public void hainan_rice(View view){
        Intent intent = new Intent(this, Hainan_chicken_rice.class);
        startActivity( intent );
    }

    public void indo_rice(View view){
        Intent intent = new Intent(this, Indo_fried_rice.class);
        startActivity( intent );
    }

    public void pineapple_rice(View view){
        Intent intent = new Intent(this, Pineapple_fried_rice.class);
        startActivity( intent );
    }

    public void thai_basil_chicken(View view){
        Intent intent = new Intent(this, Pineapple_fried_rice.class);
        startActivity( intent );
    }

    public void pho_bo(View view){
        Intent intent = new Intent(this, Pho_bo.class);
        startActivity( intent );
    }

    public void bun_thit_nuong(View view){
        Intent intent = new Intent(this, Bun_thit_nuong.class);
        startActivity( intent );
    }

    public void bun_bo_hue(View view){
        Intent intent = new Intent(this, Bun_bo_hue.class);
        startActivity( intent );
    }

    public void bun_rieu(View view){
        Intent intent = new Intent(this, Bun_rieu.class);
        startActivity( intent );
    }

    public void laksa(View view){
        Intent intent = new Intent(this, Laksa.class);
        startActivity( intent );
    }

    public void fried_noodle(View view){
        Intent intent = new Intent(this, Fried_noodle.class);
        startActivity( intent );
    }

    public void bak_kut_teh(View view){
        Intent intent = new Intent(this, Bak_kut_teh.class);
        startActivity( intent );
    }

    public void canh_chua(View view){
        Intent intent = new Intent(this, Canh_chua.class);
        startActivity( intent );
    }

    public void tom_yum(View view){
        Intent intent = new Intent(this, Tom_yum.class);
        startActivity( intent );
    }

    public void canh_artiso(View view){
        Intent intent = new Intent(this, Canh_artiso.class);
        startActivity( intent );
    }

    public void coffe(View view){
        Intent intent = new Intent(this, Coffee.class);
        startActivity( intent );
    }

    public void pulled_tea(View view){
        Intent intent = new Intent(this, Pulled_tea.class);
        startActivity( intent );
    }

    public void milo(View view){
        Intent intent = new Intent(this, Milo.class);
        startActivity( intent );
    }
}