package com.example.finalproject;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.LinkedList;

public class Laksa extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private WordListAdapter mAdapter;
    private ImageView image;
    LinkedList<String> laksa = new LinkedList<String>( Arrays.asList(
            "Description: ",
            "aksa paste is a blend of lemongrass, dried chilies, shallots, galanga, turmeric, spices, dried shrimp and shrimp paste, all blended up in the food processor, then sautéed in a little oil to deepen the flavor.",
            " ",
            "------------ Ingredients ------------",
            "3 tablespoons vegetable oil",
            "1 recipe for Laksa Paste",
            "6 cups chicken stock or broth",
            "8 kefir lime leaves",
            "1 teaspoon salt, more to taste",
            "1 tablespoon brown sugar or palm sugar",
            "1 1/2 pounds raw chicken (breast or thigh meat) cut into thin, bite-sized pieces (or sub fish or crispy tofu)",
            "1 pound raw large shrimp (raw, peeled, or sub firm fish, or more chicken or veggies )",
            "2 x 13.5 ounce cans full-fat coconut milk. Do not use “lite” – and if you like an even richer broth, add a third can.",
            "Juice from 1–2 limes",
            "fish sauce to taste ( I use 1 tablespoon)",
            "1 pound dry rice noodles  (2 ounces per person).",
            "Garnishes: bean sprouts, lime wedges, cilantro, Vietnamese mint, scallions, sambal chili paste, fried shallots (available in jars at an Asian market)",
            "OPTIONAL ADDITIONS or Substitutions: Fried tofu cubes, fish balls ( frozen), scallops or other firm fish, clams, mussels, and veggies like snow peas, mushrooms, carrots, bell pepper, chopped spinach or greens etc….",
            " ",
            "------------ Procedure ------------",
            "Make the Laksa paste- see the notes below (or use store-bought laksa paste).",
            "Cook rice noodles according to directions. Set aside. See notes for fresh noodles. ",
            "In a large heavy bottom soup pot or dutch oven, heat  oil over medium-high heat. Add all the homemade Laksa Paste  (or the 7-ounce Jar), and saute, stirring constantly until it becomes very fragrant and deep in color about 2-3 minutes. (Turn stove fan on). Add the chicken broth scraping up all the brown bits.  Add the lime leaves, salt and sugar and bring to a simmer.",
            "Add chicken and simmer 4-5 minutes. Add shrimp, cook for 2-3 minutes, add coconut milk. Simmer until heated through. Do not boil this too long or you will loose the lovely sweetness from the coconut milk– just gently warm.",
            "Add lime juice, starting with a 1 lime, and more to taste. Add fish sauce to taste, adding a teaspoon at a time. The broth should taste rich and deep, and slightly salty (the noodles will mellow the salt out) and just a little limey. If it tastes, too “fishy” add more lime juice. Guests can squeeze more lime to taste. If you want more heat, add chili flakes or chili paste.",
            "Divide the cooked rice noodles among bowls. Ladle flavorful soup over top of noodles. Top bowls with a handful of fresh bean sprouts, fresh cilantro and/or mint.  Serve with chili sauce and lime wedges.",
            "For rice noodles, calculate two ounces ( dry rice noodles ) per person."
    ));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.recyclerview );
        mRecyclerView = findViewById(R.id.recyclerview);
        mAdapter = new WordListAdapter(this, laksa);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        image = findViewById( R.id.imageView);
        image.setImageResource( R.drawable.laksa);
    }
}
