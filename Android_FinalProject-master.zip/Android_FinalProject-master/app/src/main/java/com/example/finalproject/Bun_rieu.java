package com.example.finalproject;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.LinkedList;

public class Bun_rieu extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private WordListAdapter mAdapter;
    private ImageView image;
    LinkedList<String> bun_rieu = new LinkedList<String>( Arrays.asList(
            "Description: ",
            "Bún riêu is another very popular and flavor-packed Vietnamese rice noodle soup, with soup flavored with tomatoes, shrimp paste, fish sauce and a meat broth.",
            " ",
            "------------ Ingredients ------------",
            "SOUP",
            "50g shallots about four large cloves, thinly sliced",
            "2tbsp neutral cooking oil",
            "907.2  tomatoes quartered (any type)",
            "1tsp fermented shrimp paste – Lee Kum Kee diluted in a small bowl w a bit of water for even dispersion",
            "3tbsp fish sauce",
            "1tsp salt",
            "1-2tbsp rock sugar granulated is ok too",
            "4tbsp ketchup",
            "43.5oz chicken broth or make your own broth with water and 1 lb pork ribs",
            "43.5oz water",
            "1-2tsp monosodium glutamate seasoning",

            "MEATBALLS",
            "25g shallot sliced (about two large cloves)",
            "56.7g raw shrimp shells removed, deveined",
            "302.4g ground pork",
            "5.6oz canned minced prawn or minced crab with spices. Lee brand.",
            "57g steamed or canned crab optional. If using frozen or canned, lightly squeeze to remove excess moisture.",
            "2 large eggs",
            "1 tsp pepper",
            "1 tsp sugar",
            "1 tbsp fish sauce",
            "5 stalks green onions cut into 1.5 pieces",

            "ACCOUTREMENT (ALL OPTIONAL)",
            "453.6g deep fried tofu",
            "26.8g raw bean sprouts",
            "1bunch kinh gioi / Vietnamese balm",
            "1bunch mint",
            "1bunch tia to / purple perilla",
            "shrimp paste on the side",
            "sliced limes",
            "4 thai chiles",

            "NOODLES",
            "1lb dried rice vermicelli sticks small noodle size. Thap Chua brand (but any will do)",
            " ",
            "------------ Procedure ------------",
            "Cook noodles according to package instructions, split between 4-5 bowls",

            "SOUP",
            "Thinly slice shallots, add oil to a pan and saute until light brown.",
            "Add quartered tomatoes, stir fry for 3-5 minutes until slightly soft.",
            "Add shallots, tomatoes, and all remaining soup ingredients into a large pot.",
            "Raise to high heat until it hits a boil, and boils for five minutes.",
            "Reduce the heat to medium-low or low, so it maintains a low boil while you work on the MEATBALLS.",

            "MEATBALLS",
            "Add shallots into a small food processor, pulse until finely chopped.",
            "Add shrimp, pulse 5-6 times.",
            "Add remaining ingredients (except crab and green onion) and pulse a few times until evenly mixed.",
            "Pour into a mixing bowl, add crab and lightly mix with a spoon.",
            "Using a soup spoon, scoop 1-2 tbsp size meat balls (your choice!) into the pot until you use it all",
            "Raise the heat to high and bring to a boil, then drop heat to a low boil. At most it should take 20 minutes to cook the meatballs all the way through. Check doneness by breaking a meatball in half to make sure its not soft or raw inside.",
            "During the last five minutes of cooking, drop in the chopped green onion so it slightly softens"
    ));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.recyclerview );
        mRecyclerView = findViewById(R.id.recyclerview);
        mAdapter = new WordListAdapter(this, bun_rieu);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        image = findViewById( R.id.imageView);
        image.setImageResource( R.drawable.bun_rieu);
    }
}
