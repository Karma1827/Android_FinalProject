package com.example.finalproject;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.LinkedList;

public class Nasi_lemak extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private WordListAdapter mAdapter;
    private ImageView image;
    LinkedList<String> nasilemak = new LinkedList<String>( Arrays.asList(
            "Description: ",
            "Malay Coconut Milk Rice or better known as Nasi Lemak in local is rice cooked with coconut milk, and later served with fried anchovies, sambal (spicy sauce), slices of cucumber, boiled egg and fried ground nuts.",
            " ",
            "------------ Ingredients ------------",
            "INGREDIENT A",
            "1 cup Rice",
            "50ml Coconut Milk",
            "125ml Water",
            "1 sprigs Pandan Leaf",
            "0.5 tsp Salt",
            "1 slices Ginger",
            "INGREDIENT B",
            "5g Dried Chili Pepper",
            "0.5/2 pcs Onion",
            "1 cloves Garlic",
            "0.5 tsp Shrimp Paste",
            "0.5 tsp Minced Ginger",
            "INGREDIENT C",
            "1 tbsp Cooking Oil",
            "0.5/2 pcs Onion",
            "50ml Tamarind Juice",
            "50ml Water",
            "0.5/2 tsp Salt",
            "0.5/2 tbsp Sugar",
            "INGREDIENT D",
            "10g Fried Anchovies",
            "1 Hard Boiled Eggs",
            "10g Roasted Peanuts",
            "2 pcs Cucumber Slices",
            " ",
            "------------ Procedure ------------",
            "RICE PREPARATION (45mins)",
            "Place all Ingredient A into rice cooker bowl, close rice cooker cover and let soak for 30 minutes. ",
            "Switch the rice cooker on and let it cook until it auto turns to keep warm.",
            "SAUCE PREPARATION(25mins)",
            "Place all Ingredient B into a blender and blend until it forms a smooth chilli paste.",
            "Heat up a wok with cooking oil, then toss the chilli paste into the wok and stir-fry for 20 minutes until the fragrant comes out. Pour remaining Ingredient C into the wok, stir well and let simmer on low heat for 5 minutes.",
            "DISH PREPARATION(5mis)",
            "Stir coconut milk rice in the rice cooker with a spoon to make it fluff then scoop rice into a bowl to shape before transferring to a plate.",
            "Add Ingredient D accordingly around the rice as a garnish, pour chilli sauce on top of the rice. Ready to serve."
    ));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.recyclerview );
        mRecyclerView = findViewById(R.id.recyclerview);
        mAdapter = new WordListAdapter(this, nasilemak);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        image = findViewById( R.id.imageView);
        image.setImageResource( R.drawable.nasi_lemak );
    }
}
