package com.example.finalproject;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.LinkedList;

public class Tom_yum extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private WordListAdapter mAdapter;
    private ImageView image;
    LinkedList<String> tom_yum = new LinkedList<String>( Arrays.asList(
            "Description: ",
            "A tangy, spicy, salty and subtly sweet stir fry with holy basil and chilies and minced thigh fillets were used in this Thai basil chicken (pad krapow gai or phat kaphrao gai) recipe.",
            " ",
            "------------ Ingredients ------------",
            "300g shrimp with heads and shells on",
            "BROTH:",
            "3 cup (750 ml) water",
            "1/2 cup (125 ml) chicken stock/broth , low sodium",
            "2 stalks of lemongrass , outer layers peeled",
            "1.5cm / 3/5 piece of galangal , cut into 4 slices ",
            "5 kaffir lime leaves , torn roughly ",
            "2 Thai or birdseye chillies",
            "3 garlic cloves",
            "SOUP ADD INS:",
            "120g oyster mushrooms",
            "1 roma tomato , cut into wedges",
            "1/2 white onion (medium sized), cut into wedges about 1cm thick",
            "1tsp sugar",
            "3tbsp fish sauce",
            "3tbsp lime juice",
            "Coriander/cilantro , for garnish",
            "CREAMY TOM YUM OPTION:",
            "1 1/2 tbsp Thai roasted chili sauce",
            "1/3 cup (75 ml) evaporated milk",
            " ",
            "------------ Procedure ------------",
            "BROTH:",
            "Peel the prawns. Place heads and shell in pot, reserve meat.",
            "Use a meat mallet or similar to bash the garlic, chilli and lemongrass so they burst open to release flavour. Add into pot.",
            "Crush kaffir lime leaves with your hands. Add into pot.",
            "Add galangal, stock and water. Bring to simmer on high heat, cover, then reduce to medium and simmer for 10 minutes.",
            "Strain the broth, discard the prawn shells etc, then return broth into same pot over low heat.",
            "FINISH SOUP:",
            "Add onions and mushrooms, simmer 3 minutes. Add tomatoes, simmer for 1 minute.",
            "Add prawns, simmer 2 minutes or until just cooked.",
            "Stir in sugar and fish sauce, simmer for 1 minute.",
            "Add lime juice, then taste. Adjust sweet (sugar), salt (fish sauce) and sour (lime) to your taste (trust me, you'll know when you like it!).",
            "Ladle into bowls and serve with fresh coriander and fresh chilli! This is the CLEAR version of Tom Yum.",
            "CREAMY TOM YUM:",
            "When you add sugar, also add Thai Chilli Paste and evaporated milk.",
            "Then continue with recipe!"
    ));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.recyclerview );
        mRecyclerView = findViewById(R.id.recyclerview);
        mAdapter = new WordListAdapter(this, tom_yum);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        image = findViewById( R.id.imageView);
        image.setImageResource( R.drawable.tom_yum );
    }
}
