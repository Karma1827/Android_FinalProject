package com.example.finalproject;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.LinkedList;

public class Pulled_tea extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private WordListAdapter mAdapter;
    private ImageView image;
    LinkedList<String> pulled_tea = new LinkedList<String>( Arrays.asList(
            "Description: ",
            "There’s various versions of Pineapple Fried Rice around, and this is Vietnamese version. The sweet, juicy pieces of pineapple goes so well with the savoury flavoured jasmine rice! Terrific side dish for tropical dishes, summer BBQ’s and of course, with all things Vietnam.",
            " ",
            "------------ Ingredients ------------",
            "------------ Equipment ------------",
            "2 tea mugs or cups",
            "Kettle",
            "Stainless steel jug for pouring to pull the tea",
            " ",
            "------------ Ingredients ------------",
            "250 ml boiling water",
            "2 black tea bags or ½ tbsp of loose black tea leaves",
            "2 tbsp condensed milk",
            "Ice optional",
            " ",
            "------------ Procedure ------------",
            "Place teabags (or tea strainer and loose leaves) into a mug and pour over boiling water. Steep for a few minutes until tea is dark and intense, then allow to cool for a few more minutes.",
            "Add 2 tbsp condensed milk and stir until spoon is clean.",

            "PULLING THE TEA:",
            "(Caution: Please be careful with hot tea to avoid a nasty burn!)",
            "Pour the tea into a stainless steel jug, then pour into a mug or tea glass. Try to gain as much height as possible while pouring. Repeat until tea is frothy.",
            "Serve hot or over plenty of ice for a chilled summer drink."
    ));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.recyclerview );
        mRecyclerView = findViewById(R.id.recyclerview);
        mAdapter = new WordListAdapter(this, pulled_tea);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        image = findViewById( R.id.imageView);
        image.setImageResource( R.drawable.pulled_tea);
    }
}

