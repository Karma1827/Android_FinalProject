package com.example.finalproject;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.LinkedList;

public class Bak_kut_teh extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private WordListAdapter mAdapter;
    private ImageView image;
    LinkedList<String> bak_kut_teh = new LinkedList<String>( Arrays.asList(
            "Description: ",
            "Bak Kut Teh is a Malaysian herbal soup dish made with pork ribs and Chinese herbs. Traditionally made in a claypot, this homemade recipe is easy, authentic and hearty.",
            " ",
            "------------ Ingredients ------------",
            "4 cups water",
            "1 pack pre-packed Bak Kut Teh herbs",
            "2 heads garlic",
            "400g pork ribs, cut into pieces",
            "6 dried shitake mushrooms, soaked and cut into halves",
            "1 cup tofu puffs, cut into halves",

            "SEASONING:",
            "2 tablespoons soy sauce",
            "1 teaspoon dark soy sauce",
            "1 tablespoon oyster sauce",
            "3 dashes white pepper powder",
            "salt to taste",

            "DIPPING SAUCE:",
            "4-5 bird's eyes chilies or Thai chilies, sliced",
            "1 tablespoon minced garlic",
            "1 tablespoon soy sauce",
            "1 tablespoon Indonesian ABC sweet soy sauce",
            " ",
            "------------ Procedure ------------",
            "Add the water in a big claypot (preferred) or soup pot and bring it to boil. Add the garlic, Bak Kut Teh herbs, pork ribs, mushrooms, tofu puffs and simmer on low heat for about 1 - 2 hours.",
            "Mix all the ingredients in the Dipping Sauce together. Transfer to a small condiment bowl.",
            "Add in all ingredients in Seasoning and and simmer for another 10 minutes. Serve immediately with the Dipping Sauce."
    ));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.recyclerview );
        mRecyclerView = findViewById(R.id.recyclerview);
        mAdapter = new WordListAdapter(this, bak_kut_teh);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        image = findViewById( R.id.imageView);
        image.setImageResource( R.drawable.bak_kut_teh);
    }
}
